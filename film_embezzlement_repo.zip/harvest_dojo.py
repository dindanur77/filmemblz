#!/usr/bin/env python3
"""
harvest_dojo.py
Simple harvester for DOJ press releases related to film/production finance fraud.
How it works:
- You provide a list of DOJ (justice.gov) press release URLs in `doj_urls.txt` (one per line).
- The script fetches each page, extracts title, date, text, and dollar amounts, and writes rows to output CSV.
- The script is lightweight and intended as a starting point. Improve parsing rules for production use.
Requirements: requests, beautifulsoup4, pandas
Usage: python harvest_dojo.py --urls doj_urls.txt --out harvested_cases.csv
"""

import re
import argparse
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import csv

AMOUNT_RE = re.compile(r"\$\s?[\d\.,]+(?:\s?million|\s?billion)?", re.IGNORECASE)

def extract_amounts(text):
    matches = AMOUNT_RE.findall(text)
    cleaned = []
    for m in matches:
        # normalize common million/billion shorthand (best-effort)
        s = m.replace("$","").strip().lower().replace(",","")
        if "million" in s:
            try:
                val = float(s.replace("million","").strip()) * 1_000_000
            except:
                val = None
        elif "billion" in s:
            try:
                val = float(s.replace("billion","").strip()) * 1_000_000_000
            except:
                val = None
        else:
            try:
                val = float(s)
            except:
                val = None
        cleaned.append((m, val))
    return cleaned

def parse_doj_press_release(url):
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    # title
    title_tag = soup.find(["h1","h2"])
    title = title_tag.get_text(strip=True) if title_tag else ""
    # date - justice.gov press releases often have <time> or a div with date
    date_tag = soup.find("time") or soup.find("div", {"class":"article-date"}) or soup.find("span", {"class":"date"})
    date_text = date_tag.get_text(strip=True) if date_tag else ""
    # body text
    article = soup.find("div", {"class":"field--name-body"}) or soup.find("div", {"class":"usa-prose"}) or soup.find("div", {"class":"entry-content"})
    text = article.get_text(" ", strip=True) if article else soup.get_text(" ", strip=True)
    amounts = extract_amounts(text)
    return {
        "url": url,
        "title": title,
        "date_text": date_text,
        "parsed_date": date_text,
        "amounts_found": amounts,
        "full_text_snippet": text[:2000]
    }

def main(doj_urls_file, out_csv):
    with open(doj_urls_file, "r", encoding="utf-8") as f:
        urls = [line.strip() for line in f if line.strip()]
    rows = []
    for u in urls:
        try:
            parsed = parse_doj_press_release(u)
            rows.append(parsed)
            print("Parsed:", u)
        except Exception as e:
            print("Failed:", u, str(e))
    # write to CSV
    keys = ["url","title","parsed_date","amounts_found","full_text_snippet"]
    with open(out_csv, "w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for r in rows:
            # serialize amounts_found to JSON string
            r2 = r.copy()
            r2["amounts_found"] = json.dumps(r2.get("amounts_found", []))
            writer.writerow(r2)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--urls", default="doj_urls.txt", help="file with DOJ URLs (one per line)")
    parser.add_argument("--out", default="harvested_cases.csv", help="output CSV file")
    args = parser.parse_args()
    main(args.urls, args.out)
